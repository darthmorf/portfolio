# OpenGL Project

This is a continuation of a project I worked on as part of my Coursework for my Computer Graphics Module. We were provided an overall framework by the module leader [Markus Billeter](https://www.linkedin.com/in/markus-billeter-92b89a107/) but that was mostly about providing a consistent application structure to ease marking. This can be found in original-source.zip Thanks very much to him for a great module, and the base used in this project! 

## Building & Running
To build on linux, navigate to the root directory and run `./premake5 gmake2` then `make -j6` (or `make -j6 config=release_x64` for a release build). It can then be run with `./bin/main-debug-x64-gcc.exe` (yes there is an exe extension on Linux - this was intentional by Markus).

To build on Windows, run `.\premake5.exe vs2022`. This will generate Visual Studio solution and project files - you can then open the solution file and run and build from Visual Studio. 