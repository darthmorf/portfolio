#include "2d.hpp"

void make_square_points(Mat44f aPreTransform, std::size_t aSubdivs, std::vector<Vec3f>* oPos, std::vector<Vec3f>* oNormals, std::vector<Vec2f>* oTextCoords)
{
	float u = 1.f / aSubdivs;

	std::vector<Vec3f> pos;
	std::vector<Vec3f> normals;

	for (std::size_t i = 0; i < aSubdivs; i++)
	{
		for (std::size_t j = 0; j < aSubdivs; j++)
		{
			Vec3f offset = { i * u, j * u, 0.f };

			pos.emplace_back(offset + Vec3f{ u,   u,   0.f });
			pos.emplace_back(offset + Vec3f{ 0.f, 0.f, 0.f });
			pos.emplace_back(offset + Vec3f{ u,   0.f, 0.f });

			pos.emplace_back(offset + Vec3f{ u,   u,   0.f });
			pos.emplace_back(offset + Vec3f{ 0.f, u,   0.f });
			pos.emplace_back(offset + Vec3f{ 0.f, 0.f, 0.f });

			Mat33f const N = mat44_to_mat33(transpose(invert(aPreTransform)));

			normals.emplace_back(normalize(N * (offset + Vec3f{ u,   u,   1.f })));
			normals.emplace_back(normalize(N * (offset + Vec3f{ 0.f, 0.f, 1.f })));
			normals.emplace_back(normalize(N * (offset + Vec3f{ u,   0.f, 1.f })));

			normals.emplace_back(normalize(N * (offset + Vec3f{ u,   u,   1.f })));
			normals.emplace_back(normalize(N * (offset + Vec3f{ 0.f, u,   1.f })));
			normals.emplace_back(normalize(N * (offset + Vec3f{ 0.f, 0.f, 1.f })));
		}
	}

	for (auto& p : pos)
	{
		oTextCoords->emplace_back(Vec2f{ p.x, p.y });

		Vec4f p4{ p.x, p.y, p.z, 1.f };
		Vec4f t = aPreTransform * p4;
		t /= t.w;

		p = Vec3f{ t.x, t.y, t.z };

		oPos->emplace_back(p);
	}

	for (auto& n : normals)
	{
		oNormals->emplace_back(n);
	}
}

SimpleMeshData make_square(Vec4f aColor, float aDiffuse, float aSpecular, float aEmissive, Vec3f aTextureIndex, Mat44f aPreTransform, std::size_t aSubdivs)
{
	std::vector<Vec3f> pos;
	std::vector<Vec3f> normals;
	std::vector<Vec2f> textCoords;

	make_square_points(aPreTransform, aSubdivs, &pos, &normals, &textCoords);

	std::vector colors(pos.size(), aColor);
	std::vector diffuseSpecularEmissive(pos.size(), Vec3f{aDiffuse, aSpecular, aEmissive});
	std::vector textureIndex(pos.size(), aTextureIndex);

	return SimpleMeshData{ std::move(pos), std::move(colors), std::move(normals), std::move(diffuseSpecularEmissive), std::move(textCoords), std::move(textureIndex)};
}