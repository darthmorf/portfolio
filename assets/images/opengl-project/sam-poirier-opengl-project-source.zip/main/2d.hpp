#ifndef twod_HPP
#define twod_HPP

#include <vector>

#include <cstdlib>

#include "simple_mesh.hpp"

#include "../vmlib/vec3.hpp"
#include "../vmlib/mat44.hpp"
#include "../vmlib/mat33.hpp"


void make_square_points(
	Mat44f aPreTransform,
	std::size_t aSubdivs,
	std::vector<Vec3f>* oPos,
	std::vector<Vec3f>* oNormals,
	std::vector<Vec2f>* oTextCoords
);

SimpleMeshData make_square(
	Vec4f aColor = { 1.f, 1.f, 1.f, 1.f },
	float aDiffuse = 1.f,
	float aSpecular = 0.f,
	float aEmissive = 0.f,
	Vec3f aTextureIndex = {0.f, 0.f, 0.f},
	Mat44f aPreTransform = kIdentity44f,
	std::size_t aSubdivs = 1
);

#endif // twod_HPP