#include "cube.hpp"

inline float d2r(float aAngle)  // Degrees to radians
{
	return aAngle * 3.1415926f / 180.f;
}

SimpleMeshData make_cube(Vec4f aColor, float aDiffuse, float aSpecular, float aEmissive, Mat44f aPreTransform)
{
	std::vector<Vec3f> pos;
	std::vector<Vec3f> normals;
	std::vector<Vec2f> textCoords;

	aPreTransform = aPreTransform * make_translation({ 0.f, 0.f, 1.f });

	make_square_points(kIdentity44f, 1, &pos, &normals, &textCoords);
	make_square_points(make_rotation_y(d2r(-90)) * make_translation({ -1.f, 0.f, 0.f }),
		1, &pos, &normals, &textCoords
	); 
	make_square_points(make_rotation_y(d2r(90)) * make_translation({ 0.f, 0.f, 1.f }),
		1, &pos, &normals, &textCoords
	);
	make_square_points(make_rotation_y(d2r(180)) * make_translation({ -1.f, 0.f, 1.f }),
		1, &pos, &normals, &textCoords
	);

	make_square_points(make_rotation_x(d2r(-90)) * make_translation({ 0.f, 0.f, 1.f }),
		1, &pos, &normals, &textCoords
	);
	make_square_points(make_rotation_x(d2r(90)) * make_translation({ 0.f, -1.f, 0.f }),
		1, &pos, &normals, &textCoords
	);

	for (auto& p : pos)
	{
		Vec4f p4{ p.x, p.y, p.z, 1.f };
		Vec4f t = aPreTransform * p4;
		t /= t.w;

		p = Vec3f{ t.x, t.y, t.z };
	}

	std::vector colors(pos.size(), aColor);
	std::vector diffuseSpecularEmissive(pos.size(), Vec3f{aDiffuse, aSpecular, aEmissive});
	std::vector textureIndex(pos.size(), Vec3f{0, 0, 0});

	return SimpleMeshData{ std::move(pos), std::move(colors), std::move(normals), std::move(diffuseSpecularEmissive), std::move(textCoords), std::move(textureIndex) };
}