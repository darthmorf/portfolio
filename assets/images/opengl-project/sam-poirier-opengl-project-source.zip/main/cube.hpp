#ifndef CUBE_HPP
#define CUBE_HPP

#include <vector>

#include <cstdlib>

#include "simple_mesh.hpp"
#include "2d.hpp"

#include "../vmlib/vec3.hpp"
#include "../vmlib/mat44.hpp"

SimpleMeshData make_cube(
	Vec4f aColor = { 1.f, 1.f, 1.f, 1.f },
	Vec3f* aMaterial = 0,
	Vec3f aTextureIndex = {0, 0, 0},
	Mat44f aPreTransform = kIdentity44f
);

#endif // CUBE_HPP
