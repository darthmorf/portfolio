#include "cylinder.hpp"

// TODO : improve method do avoid vertex duplication
SimpleMeshData make_cylinder(bool aCapped, std::size_t aSubdivs, Vec4f aColor, Vec3f* aMaterial, Vec3f aTextureIndex, Mat44f aPreTransform)
{
	std::vector<Vec3f> pos;
	std::vector<Vec3f> normals;
	std::vector<Vec2f> textCoords;

	float prevY = std::cos(0.f);
	float prevZ = std::sin(0.f);

	Vec3f frontMiddle = { 0.f, 0.f, 0.f };
	Vec3f backMiddle = { 1.f, 0.f, 0.f };

	Mat33f const N = mat44_to_mat33(transpose(invert(aPreTransform)));

	for (std::size_t i = 0; i < aSubdivs; i++)
	{
		float const angle = (i + 1) / float(aSubdivs) * 2.f * 3.1415926f;

		float y = std::cos(angle);
		float z = std::sin(angle);

		// Two triangles (3 * 2 positions) - create one segment of the cylinder's shell
		pos.emplace_back(Vec3f{ 0.f, prevY, prevZ });
		pos.emplace_back(Vec3f{ 0.f, y, z });
		pos.emplace_back(Vec3f{ 1.f, prevY, prevZ });

		pos.emplace_back(Vec3f{ 0.f, y, z });
		pos.emplace_back(Vec3f{ 1.f, y, z });
		pos.emplace_back(Vec3f{ 1.f, prevY, prevZ });

		// Calculate normals for each point
		Vec3f prevN = normalize(N * Vec3f{ 0, prevY, prevZ });
		Vec3f n = normalize(N * Vec3f{ 0, y, z });

		normals.emplace_back(prevN);
		normals.emplace_back(n);
		normals.emplace_back(prevN);

		normals.emplace_back(n);
		normals.emplace_back(n);
		normals.emplace_back(prevN);

		if (aCapped)
		{
			pos.emplace_back(Vec3f{ 0.f, y, z });
			pos.emplace_back(Vec3f{ 0.f, prevY, prevZ });
			pos.emplace_back(frontMiddle);

			pos.emplace_back(backMiddle);
			pos.emplace_back(Vec3f{ 1.f, prevY, prevZ });
			pos.emplace_back(Vec3f{ 1.f, y, z });

			Vec3f frontCapN = normalize(N * Vec3f{ -1, 0, 0 });
			Vec3f backCapN = normalize(N * Vec3f{ 1, 0, 0 });

			normals.emplace_back(frontCapN);
			normals.emplace_back(frontCapN);
			normals.emplace_back(frontCapN);

			normals.emplace_back(backCapN);
			normals.emplace_back(backCapN);
			normals.emplace_back(backCapN);
		}

		prevY = y;
		prevZ = z;
	}

	for (auto& p : pos)
	{
		textCoords.push_back({ p.x, p.y });

		Vec4f p4{ p.x, p.y, p.z, 1.f };
		Vec4f t = aPreTransform * p4;
		t /= t.w;

		p = Vec3f{ t.x, t.y, t.z };
	}

	std::vector colors(pos.size(), aColor);
	std::vector materials(pos.size(), *aMaterial);
	std::vector textureIndex(pos.size(), aTextureIndex);

	return SimpleMeshData{ std::move(pos), std::move(colors), std::move(normals), std::move(materials), std::move(textCoords), std::move(textureIndex) };
}