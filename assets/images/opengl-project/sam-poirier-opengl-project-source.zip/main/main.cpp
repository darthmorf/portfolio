#include "../third_party/imgui/imgui.h"
#include "../third_party/imgui/imgui_impl_glfw.h"
#include "../third_party/imgui/imgui_impl_opengl3.h"

#include <glad.h>
#include <GLFW/glfw3.h>
#include <stb_image_write.h>

#include <typeinfo>
#include <stdexcept>

#include <cstdio>
#include <cstdlib>

#include "../support/error.hpp"
#include "../support/program.hpp"
#include "../support/checkpoint.hpp"
#include "../support/debug_output.hpp"

#include "../vmlib/vec4.hpp"
#include "../vmlib/mat44.hpp"

#include "defaults.hpp"
#include "cone.hpp"
#include "cylinder.hpp"
#include "cube.hpp"
#include "2d.hpp"

namespace
{
	constexpr char const* kWindowTitle = "COMP3811 - Coursework 2";
	
	constexpr float kPi_ = 3.1415926f;

	// Defines the property of a point light
	struct Light
	{
		Vec3f pos;
		Vec3f color;
		float strength;
	};

	struct State_
	{
		ShaderProgram* prog;

		// State related to camera and other rendering options
		struct CamCtrl_
		{
			const Vec3f defaultPos = { -38, -28, -48 };
			const float defaultPitch = .22f;
			const float defaultYaw = -.56f;

			bool cameraActive;
			bool takeScreenshot = false;
			bool showDebugUi = false;
			
			float speed = 120.f;
			float slowModifier = 0.1f;
			float fastModifier = 3.f;

			float yaw = defaultYaw;
			float pitch = defaultPitch;
			float currentX = 0.f;
			float currentY = 0.f;

			Vec3f deltaPos;
			Vec3f pos = defaultPos;			

			Mat44f world2camera;
			Mat44f billboardTransform;
			bool pitchBillboards = false;

		} camControl;

		// State to control animations
		struct AnimControl
		{
			float speed = 2.f;
			float speedModifier = 0.5f;
			bool animationPaused = false;

			float slideChangeTime = 10.f;


		} animControl;

		struct DebugUi
		{
			bool drawWireFrame = false;
			bool showDebug = false;
			bool drawHands = true;
			bool drawObj = true;

		} debugUi;

		struct Lighting 
		{
			Light light01;
			Light light02;
			Light light03;
			Light ambient;

		} lighting;

		struct Materials
		{
			Vec3f general;
			Vec3f shiny;
			Vec3f emissive;

		} materials;
	};

	void glfw_callback_error_( int, char const* );

	void glfw_callback_key_(GLFWwindow*, int, int, int, int);
	void glfw_callback_motion_(GLFWwindow*, double, double);

	struct GLFWCleanupHelper
	{
		~GLFWCleanupHelper();
	};
	struct GLFWWindowDeleter
	{
		~GLFWWindowDeleter();
		GLFWwindow* window;
	};
}

inline float d2r(float aAngle) // Degrees to radians
{
	return aAngle * kPi_ / 180.f;
}

// Defines our static debug meshes to place in the scene
std::vector<SimpleMeshData> setup_static_debug_meshes(std::vector<Light> aLights)
{
	std::vector<SimpleMeshData> meshes;
	float rotation = d2r(90);

	// Light positions
	for (size_t i = 0; i < aLights.size(); i++)
	{
		Vec4f color = Vec4f{ aLights[i].color.x, aLights[i].color.y, aLights[i].color.z, 1.f };
		SimpleMeshData lightIndicator = make_cube(color, 0.f, 0.f, 0.f,
			make_translation(aLights[i].pos + Vec3f{-0.5f, -0.5f, -0.5f})
		);
		meshes.emplace_back(lightIndicator);
	}	

	// Generate axis arrows
	SimpleMeshData xcylinder = make_cylinder(true, 16, Vec4f{ 1.f, 0.f, 0.f, 1.f }, 0, 0, 0,
		make_scaling(10.f, 0.2f, 0.2f)
	);
	meshes.emplace_back(xcylinder);
	SimpleMeshData xcone = make_cone(true, 16, Vec4f{ 0.f, 0.f, 0.f, 1.f },
		make_scaling(2.f, 0.6f, 0.6f) * make_translation({ 5.01f, 0.f, 0.f })
	);
	meshes.emplace_back(xcone);

	SimpleMeshData ycylinder = make_cylinder(true, 16, Vec4f{ 0.f, 1.f, 0.f, 1.f }, 0, 0, 0,
		make_rotation_z(rotation) * make_scaling(10.f, 0.2f, 0.2f)
	);
	meshes.emplace_back(ycylinder);
	SimpleMeshData ycone = make_cone(true, 16, Vec4f{ 0.f, 0.f, 0.f, 1.f },
		make_rotation_z(rotation) * make_scaling(2.f, 0.6f, 0.6f) * make_translation({ 5.01f, 0.f, 0.f })
	);
	meshes.emplace_back(ycone);

	SimpleMeshData zcylinder = make_cylinder(true, 16, Vec4f{ 0.f, 0.f, 1.f, 1.f }, 0, 0, 0,
		make_rotation_y(-rotation) * make_scaling(10.f, 0.2f, 0.2f)
	);
	meshes.emplace_back(zcylinder);
	SimpleMeshData zcone = make_cone(true, 16, Vec4f{ 0.f, 0.f, 0.f, 1.f },
		make_rotation_y(-rotation) * make_scaling(2.f, 0.6f, 0.6f) * make_translation({ 5.01f, 0.f, 0.f })
	);
	meshes.emplace_back(zcone); 


	return meshes;
}

// Defines our static lit meshes to place in the scene
std::vector<SimpleMeshData> setup_static_lit_meshes(State_ *aState)
{
	// Unused paramters
	(void)aState;

	std::vector<SimpleMeshData> meshes;


	return meshes;
}

// Meshes that are animated, so need to be redefined every tick
std::vector<SimpleMeshData> setup_dynamic_lit_meshes(Vec3f aAnimationOffset, State_ *aState)
{
	std::vector<SimpleMeshData> meshes;

	// General Size Constants
	const float floorWidth = 100.f;
	const float floorHeight = 60.f;
	const float ceilingHeight = 70.f;

	const float rowDepth = 11.f;
	const float rowHeight = 5.f;
	const std::size_t rowCount = 9; // Changing this number will change the amount of rows generated - no need to tweak anything else!

	// Colors & Lighting
	const Vec4f floorColor = Vec4f{ .28f, .0f, .0f, 1.f };
	const Vec4f wallColor = Vec4f{ .8f, .8f, .8f, 1.f };
	const Vec4f ceilingColor = Vec4f{ .1f, .1f, .1f, 1.f };
	const Vec4f woodColor = Vec4f{ .16f, .10f, .04f, 1.f };
	Vec4f standColor = Vec4f{ 0.1f, 0.1f, 0.1f, 1.f };

	const Vec3f defaultTextureIndex = Vec3f{ 0, 0, 0 };


	// Room Bounds

	SimpleMeshData floor = make_square(floorColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
		make_translation({ -floorWidth / 2, 0.f, floorHeight / 2 + rowDepth }) * make_rotation_x(d2r(-90)) * make_scaling(floorWidth, floorHeight + rowDepth, 1.f)
	);
	meshes.emplace_back(floor);

	SimpleMeshData frontWall = make_square(wallColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
		make_translation({ -floorWidth / 2, 0.f, -floorHeight / 2 }) * make_scaling(floorWidth, ceilingHeight, 1.f)
	);
	meshes.emplace_back(frontWall);

	SimpleMeshData rightFrontWall = make_square(wallColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
		make_translation({ floorWidth / 2, 0.f, -floorHeight / 2 }) * make_rotation_y(d2r(-90)) * make_scaling(floorHeight + rowDepth, ceilingHeight, 1.f)
	);
	meshes.emplace_back(rightFrontWall);

	SimpleMeshData leftFrontWall = make_square(wallColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
		make_translation({ -floorWidth / 2, 0.f, floorHeight / 2 + rowDepth }) * make_rotation_y(d2r(90)) * make_scaling(floorHeight + rowDepth, ceilingHeight, 1.f)
	);
	meshes.emplace_back(leftFrontWall);

	SimpleMeshData backWall = make_square(wallColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
		make_translation({ floorWidth / 2, (rowCount + 1) * rowHeight, floorHeight / 2 + (rowCount + 1) * rowDepth }) * make_rotation_y(d2r(180)) * make_scaling(floorWidth, ceilingHeight, 1.f)
	);
	meshes.emplace_back(backWall);

	SimpleMeshData frontCeiling = make_square(ceilingColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
		make_translation({ -floorWidth / 2, ceilingHeight, -floorHeight / 2 }) * make_rotation_x(d2r(90)) * make_scaling(floorWidth, floorHeight + rowDepth, 1.f)
	);
	meshes.emplace_back(frontCeiling);

	// Determine angled ceiling
	float theta = atan(rowHeight / rowDepth);
	float scale = ((rowCount - 0) * rowHeight) / sin(theta);

	SimpleMeshData backCeiling = make_square(ceilingColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
		make_translation({ -floorWidth / 2, ceilingHeight, floorHeight / 2 + rowDepth }) * make_rotation_x(d2r(90) - theta) * make_scaling(floorWidth, scale, 1.f)
	);
	meshes.emplace_back(backCeiling);


	// Seats

	// Front Desk
	SimpleMeshData woodDesksFront = make_cube(woodColor, aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
		make_translation({ -floorWidth / 2, 0.f, floorHeight / 2, }) * make_scaling(floorWidth, 10.f, 1.f)
	);
	meshes.emplace_back(woodDesksFront);

	SimpleMeshData desksFrontTop = make_cube(woodColor, aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
		make_rotation_x(d2r(90)) * make_translation({ -floorWidth / 2, floorHeight / 2, -11.f, }) * make_scaling(floorWidth, 5.f, 1.f)
	);
	meshes.emplace_back(desksFrontTop);

	// Inital Row of seats
	Vec3f startRowPos = { -floorWidth / 2, 0.f, floorHeight / 2 };

	for (int x = 0; x < floorWidth; x += 10)
	{
		Vec3f pos = startRowPos + Vec3f{ x + 1.f, 2.f, 10.f };

		SimpleMeshData seatsBack = make_cube(Vec4f{ .06f, .13f, .31f, 1.f }, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
			make_translation(pos) * make_scaling(8.f, 8.f, 1.f)
		);
		meshes.emplace_back(seatsBack);

		pos.z -= 1;

		SimpleMeshData seatsBase = make_cube(Vec4f{ .06f, .13f, .31f, 1.f }, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
			make_translation(pos) * make_scaling(8.f, 4.f, 1.f)
		);
		meshes.emplace_back(seatsBase);
	}


	// Dynamically create the rest of the rows
	Vec3f rowPos = startRowPos + Vec3f{ 0.f, 0.f, rowDepth };

	for (std::size_t i = 0; i < rowCount; i++)
	{
		SimpleMeshData desksFront = make_cube(wallColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
			make_translation(rowPos) * make_scaling(floorWidth, 15.f, 1.f)
		);
		meshes.emplace_back(desksFront);

		Vec3f deskPos = rowPos + Vec3f{ 0.f, 16.f, 0.f };
		SimpleMeshData desksTop = make_cube(woodColor, aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
			make_translation(deskPos) * make_rotation_x(d2r(90)) * make_scaling(floorWidth, rowHeight, 1.f)
		);
		meshes.emplace_back(desksTop);

		Vec3f floorPos = rowPos + Vec3f{ 0.f, rowHeight, rowDepth };
		SimpleMeshData rowFloor = make_square(floorColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
			make_translation(floorPos) * make_rotation_x(d2r(-90)) * make_scaling(floorWidth, rowDepth, 1.f)
		);
		meshes.emplace_back(rowFloor);

		Vec3f rowLeftWallPos = rowPos + Vec3f{ 0.f, rowHeight, rowDepth };
		SimpleMeshData rowLeftWall = make_square(wallColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
			make_translation(rowLeftWallPos) * make_rotation_y(d2r(90)) * make_scaling(rowDepth, ceilingHeight, 1.f)
		);
		meshes.emplace_back(rowLeftWall);

		Vec3f rowRightWallPos = rowPos + Vec3f{ 0.f, rowHeight, 0.f };
		rowRightWallPos.x = -rowRightWallPos.x;
		SimpleMeshData rowRightWall = make_square(wallColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, defaultTextureIndex,
			make_translation(rowRightWallPos) * make_rotation_y(d2r(-90)) * make_scaling(rowDepth, ceilingHeight, 1.f)
		);
		meshes.emplace_back(rowRightWall);

		// Generate seats
		for (int x = 0; x < floorWidth; x += 10)
		{
			Vec3f pos = rowPos + Vec3f{ x + 1.f, 7.f, 10.f };

			SimpleMeshData seatsBack = make_cube(Vec4f{ .06f, .13f, .31f, 1.f }, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
				make_translation(pos) * make_scaling(8.f, 8.f, 1.f)
			);
			meshes.emplace_back(seatsBack);

			pos.z -= 1;

			SimpleMeshData seatsBase = make_cube(Vec4f{ .06f, .13f, .31f, 1.f }, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
				make_translation(pos) * make_scaling(8.f, 4.f, 1.f)
			);
			meshes.emplace_back(seatsBase);
		}

		rowPos = rowPos + Vec3f{ 0.f, rowHeight, rowDepth };
	}

	// Lecturer Table

	Vec3f tablePos = { 25.f, 0.f, 5.f };
	Vec4f tableColor = { .16f, .10f, .04f, 1.f };

	Vec3f tableLeg01Pos = tablePos;
	SimpleMeshData tableLeg01 = make_cylinder(true, 128, tableColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
		make_translation(tableLeg01Pos) * make_rotation_z(d2r(90)) * make_scaling(10.f, .5f, .5f)
	);
	meshes.emplace_back(tableLeg01);

	Vec3f tableLeg02Pos = tablePos + Vec3f{ 0.f, 0.f, 5.f };
	SimpleMeshData tableLeg02 = make_cylinder(true, 128, tableColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
		make_translation(tableLeg02Pos) * make_rotation_z(d2r(90)) * make_scaling(10.f, .5f, .5f)
	);
	meshes.emplace_back(tableLeg02);

	Vec3f tableLeg03Pos = tablePos + Vec3f{ 10.f, 0.f, 0.f };
	SimpleMeshData tableLeg03 = make_cylinder(true, 128, tableColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
		make_translation(tableLeg03Pos) * make_rotation_z(d2r(90)) * make_scaling(10.f, .5f, .5f)
	);
	meshes.emplace_back(tableLeg03);

	Vec3f tableLeg04Pos = tablePos + Vec3f{ 10.f, 0.f, 5.f };
	SimpleMeshData tableLeg04 = make_cylinder(true, 128, tableColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
		make_translation(tableLeg04Pos) * make_rotation_z(d2r(90)) * make_scaling(10.f, .5f, .5f)
	);
	meshes.emplace_back(tableLeg04);

	Vec3f tableTopPos = tablePos + Vec3f{ -1.f, 10.f, -1.f };
	SimpleMeshData tableTop = make_cube(tableColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
		make_translation(tableTopPos) * make_scaling(12.f, .5f, 7.f)
	);
	meshes.emplace_back(tableTop);

	if (aState->debugUi.drawObj)
	{
		// Model from https://www.turbosquid.com/3d-models/free-max-model-ea-108-aluminium-chair/620426
		SimpleMeshData chair = load_wavefront_obj("assets/chair_a.obj", Vec4f{ 0.8f, 0.8f, 1.f, 1.f }, aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
			make_translation(tablePos + Vec3f{ 10.f, 0.f, -5.f }) * make_scaling(0.15f, 0.15f, 0.15f) * make_rotation_y(d2r(-110))
		);
		meshes.emplace_back(chair);
	}


	// Table Objects

	Vec3f tableSurface = tablePos + Vec3f{ -1.f, 10.5f, -1.f };
	Vec4f laptopColor = Vec4f{ 0.05f, 0.05f, 0.05f, 1.f };

	//Laptop

	Vec3f laptopPosition = tableSurface + Vec3f{ 3.f, 0.f, 2.f };
	SimpleMeshData laptopBase = make_cube(laptopColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
		make_translation(laptopPosition) * make_scaling(5.f, 0.1f, 3.f)
	);
	meshes.emplace_back(laptopBase);

	Vec3f laptopLidPosition = laptopPosition + Vec3f{ 0.01f, 0.f, 3.f };
	SimpleMeshData laptopLid = make_cube(laptopColor, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
		make_translation(laptopLidPosition) * make_rotation_x(d2r(-70)) * make_scaling(4.98f, 0.1f, 3.f)
	);
	meshes.emplace_back(laptopLid);

	SimpleMeshData laptopLidTex = make_square(laptopColor, aState->materials.general.x, aState->materials.general.y, aState->materials.emissive.z, Vec3f{ 2.0f, 2.f, 3.0f },
		make_translation(laptopLidPosition + Vec3f{ 0.f, 0.f, 0.01f }) * make_rotation_x(d2r(20)) * make_scaling(4.98f, 3.f, 1.f)
	);
	meshes.emplace_back(laptopLidTex);

	// Laptop Screen
	Vec3f laptopScreenPosition = Vec3f{ 31.81f, 10.85f, 8.975f };
	SimpleMeshData laptopScreen = make_square(Vec4f{ 1.f, 1.f, 1.f, 1.f }, aState->materials.emissive.x, aState->materials.emissive.y, aState->materials.emissive.z * 0.1f, Vec3f{0.f, 0.f, 4.f},
		make_translation(laptopScreenPosition) * make_rotation_y(d2r(180)) * make_rotation_x(d2r(-20)) * make_scaling(4.6f, 2.4f, 1.f)
	);
	meshes.emplace_back(laptopScreen);

	laptopPosition.x += .3f;
	laptopPosition.y += .1f;
	laptopPosition.z += 1.f;

	float startX = laptopPosition.x;

	for (std::size_t y = 0; y < 4; y++)
	{
		laptopPosition.x = startX;
		std::size_t width = 11;

		if (y % 2 != 0)
		{
			width -= 1;
			laptopPosition.x += .15f;
		}

		for (std::size_t x = 0; x < width; x++)
		{
			SimpleMeshData key = make_cube(Vec4f{ 0.2f, 0.2f, 0.2f, 1.f }, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z,
				make_translation(laptopPosition) * make_scaling(.3f, 0.01f, .3f)
			);
			meshes.emplace_back(key);

			laptopPosition.x += .4f;
		}

		laptopPosition.z += .4f;
	}

	// Transparent cup

	SimpleMeshData cup = make_cylinder(true, 128, Vec4f{ 0.f, 1.f, 1.f, 0.5f }, aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
		make_translation(tableSurface + Vec3f{ 1.f, 0.f, 6.f }) * make_rotation_z(d2r(90)) * make_scaling(2.f, .5f, .5f)
	);
	meshes.emplace_back(cup);

	// Animated Markus Robot

	Vec3f offset = aAnimationOffset + Vec3f{ 25.f, 0.f, 0.f };

	SimpleMeshData leftWheel = make_cylinder(true, 128, standColor, aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
		make_translation(offset + Vec3f{ -2.f, 1.f, 0.f }) * make_scaling(0.5f, 1.f, 1.f)
	);
	meshes.emplace_back(leftWheel);

	SimpleMeshData rightWheel = make_cylinder(true, 128, standColor, aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
		make_translation(offset + Vec3f{ 2.f, 1.f, 0.f }) * make_scaling(0.5f, 1.f, 1.f)
	);
	meshes.emplace_back(rightWheel);

	SimpleMeshData wheelMiddle = make_cylinder(true, 128, standColor, aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
		make_translation(offset + Vec3f{ -2.f, 1.f, 0.f }) * make_scaling(4.f, .5f, .5f)
	);
	meshes.emplace_back(wheelMiddle);

	SimpleMeshData neck = make_cylinder(true, 128, standColor, aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
		make_translation(offset + Vec3f{ 0.25f/2, 1.f, 0.f }) * make_rotation_z(d2r(90)) * make_scaling(10.f, .25f, .25f)
	);
	meshes.emplace_back(neck);

	SimpleMeshData displayBack = make_cube(standColor,aState->materials.shiny.x, aState->materials.shiny.y, aState->materials.shiny.z,
		make_translation(offset + Vec3f{-0.75f, 11.f, -.25f}) * make_scaling(2.f, 3.f, 0.5f)
	);
	meshes.emplace_back(displayBack);

	SimpleMeshData display = make_square(Vec4f{ 1.f, 1.f, 1.f, 1.f }, aState->materials.emissive.x, aState->materials.emissive.y, aState->materials.emissive.z, Vec3f{0.0f, 0.0f, 1.f},
		make_translation(offset + Vec3f{ -0.75f, 11.f, .26f }) * make_scaling(2.f, 3.f, 0.5f)
	);
	meshes.emplace_back(display);

	SimpleMeshData projection = make_square(Vec4f{ 1.f, 1.f, 1.f, .7f }, 0.1f, 0.1f, .25f, Vec3f{ 0.0f, 0.0f, 4.f },
		make_translation({ -100 / 3, 17.f, -60 / 2 + 0.01f }) * make_scaling(60, 35, 1.f)
	);
	meshes.emplace_back(projection);


	// Billboarding etc

	SimpleMeshData billboard = make_square(Vec4f{ 1.f, 1.f, 1.f, 1.f }, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, Vec3f{ 6.0f, 0.0f, 0.f },
		make_translation(Vec3f{ -35, 8, 35 }) * aState->camControl.billboardTransform * make_scaling(9.f, 27.f, 1.f)
	);
	meshes.emplace_back(billboard);

	if (aState->debugUi.drawHands)
	{
		SimpleMeshData hands = make_square(Vec4f{ 1.f, 1.f, 1.f, 1.f }, aState->materials.general.x, aState->materials.general.y, aState->materials.general.z, Vec3f{ 5.0f, 0.0f, 0.f },
			aState->camControl.world2camera * make_scaling(2.5f, 2.f, 1.f) * make_translation(Vec3f{ -.5f, -.35f, 0 }) * make_rotation_x(d2r(-30))
		);
		meshes.emplace_back(hands);
	}

	

	return meshes;
}

// Draw any meshes that ignore lighting
void draw_unlit_meshes(GLuint aVao, std::size_t aVertexCount, Mat44f aProjectionMatrix)
{
	Vec3f unlit = Vec3f{ 1.f, 1.f, 1.f };

	glBindVertexArray(aVao);

	// Pass projection matrix to OpenGL
	glUniformMatrix4fv(
		0,
		1, GL_TRUE, aProjectionMatrix.v
	);

	// Pass normal matrix to OpenGL
	glUniformMatrix3fv(
		1,
		1, GL_TRUE, kIdentity44f.v
	);

	// Pass misc uniform lighting data
	glUniform3fv(2, 1, &unlit.x);
	glUniform3f(3, unlit.x, unlit.y, unlit.z);
	glUniform3f(4, unlit.x, unlit.y, unlit.z);

	// Draw triangles
	glDrawArrays(GL_TRIANGLES, 0, (GLsizei)aVertexCount);
}

// Draw any meshes that are lit
void draw_default_light_meshes(GLuint aVao, std::size_t aVertexCount, Mat44f aProjectionMatrix, 
	Mat33f aNormalMatrix, Vec3f aSceneAmbient, std::vector<Light> aLights, Vec3f aViewDir, State_ *aState)
{
	glBindVertexArray(aVao);

	// Pass projection matrix to OpenGL
	glUniformMatrix4fv(
		0,
		1, GL_TRUE, aProjectionMatrix.v
	);

	// Pass normal matrix to OpenGL
	glUniformMatrix3fv(
		1,
		1, GL_TRUE, aNormalMatrix.v
	);

	// Pass misc uniform lighting data

	glUniform3f(2, aSceneAmbient.x, aSceneAmbient.y, aSceneAmbient.z);
	glUniform3f(3, aViewDir.x, aViewDir.y, aViewDir.z);
	
	// Pass in light data (in array format)
	int uniformIndex = 3;
	for (size_t i = 0; i < aLights.size(); i++)
	{
		glUniform3f(uniformIndex + 1, aLights[i].pos.x, aLights[i].pos.y, aLights[i].pos.z);
		glUniform3f(uniformIndex + 2, aLights[i].color.x, aLights[i].color.y, aLights[i].color.z);
		glUniform1f(uniformIndex + 3, aLights[i].strength);

		uniformIndex += 3;
	}

	// Draw in wireframe mode?
	if (aState->debugUi.drawWireFrame)
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	}
	else
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}

	glDrawArrays(GL_TRIANGLES, 0, (GLsizei)aVertexCount);
}

int main() try
{
	// Initialize GLFW
	if( GLFW_TRUE != glfwInit() )
	{
		char const* msg = nullptr;
		int ecode = glfwGetError( &msg );
		throw Error( "glfwInit() failed with '%s' (%d)", msg, ecode );
	}

	// Ensure that we call glfwTerminate() at the end of the program.
	GLFWCleanupHelper cleanupHelper;

	// Configure GLFW and create window
	glfwSetErrorCallback( &glfw_callback_error_ );

	glfwWindowHint( GLFW_SRGB_CAPABLE, GLFW_TRUE );
	glfwWindowHint( GLFW_DOUBLEBUFFER, GLFW_TRUE );
	glfwWindowHint( GLFW_RESIZABLE, GLFW_TRUE );
	glfwWindowHint( GLFW_CONTEXT_VERSION_MAJOR, 4 );
	glfwWindowHint( GLFW_CONTEXT_VERSION_MINOR, 3 );
	glfwWindowHint( GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE );
	glfwWindowHint( GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE );

	glfwWindowHint( GLFW_DEPTH_BITS, 24 );

#	if !defined(NDEBUG)
	// When building in debug mode, request an OpenGL debug context. This
	// enables additional debugging features. However, this can carry extra
	// overheads. We therefore do not do this for release builds.
	glfwWindowHint( GLFW_OPENGL_DEBUG_CONTEXT, GLFW_TRUE );
#	endif // ~ !NDEBUG

	GLFWwindow* window = glfwCreateWindow(
		1280,
		720,
		kWindowTitle,
		nullptr, nullptr
	);

	if( !window )
	{
		char const* msg = nullptr;
		int ecode = glfwGetError( &msg );
		throw Error( "glfwCreateWindow() failed with '%s' (%d)", msg, ecode );
	}

	GLFWWindowDeleter windowDeleter{ window };

	// Set up event handling
	State_ state;

	glfwSetWindowUserPointer(window, &state);

	glfwSetKeyCallback(window, &glfw_callback_key_);
	glfwSetCursorPosCallback(window, &glfw_callback_motion_);

	// Set up drawing stuff
	glfwMakeContextCurrent( window );
	glfwSwapInterval( 1 ); // V-Sync is on.

	// Initialize GLAD
	// This will load the OpenGL API. We mustn't make any OpenGL calls before this!
	if( !gladLoadGLLoader( (GLADloadproc)&glfwGetProcAddress ) )
		throw Error( "gladLoaDGLLoader() failed - cannot load GL API!" );

	std::printf( "RENDERER %s\n", glGetString( GL_RENDERER ) );
	std::printf( "VENDOR %s\n", glGetString( GL_VENDOR ) );
	std::printf( "VERSION %s\n", glGetString( GL_VERSION ) );
	std::printf( "SHADING_LANGUAGE_VERSION %s\n", glGetString( GL_SHADING_LANGUAGE_VERSION ) );

	// Ddebug output
#	if !defined(NDEBUG)
	setup_gl_debug_output();
#	endif // ~ !NDEBUG

	// Global GL state
	OGL_CHECKPOINT_ALWAYS();

	glEnable(GL_FRAMEBUFFER_SRGB); // Automatic conversion sRGB conversion of colors when we output from the fragment shader
	glEnable(GL_CULL_FACE); // Cull triangles with a clockwise winding
	glEnable(GL_DEPTH_TEST); // Enabled depth testing to ensure objects are drawn in the correct order

	// Enable blending (transparency) and determine blend method
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glClearColor(0.01f, 0.01f, 0.01f, 0.0f); // Set default/background color

	OGL_CHECKPOINT_ALWAYS();

	// Get actual framebuffer size.
	// This can be different from the window size, as standard window
	// decorations (title bar, borders, ...) may be included in the window size
	// but not be part of the drawable surface area.
	int iwidth, iheight;
	glfwGetFramebufferSize( window, &iwidth, &iheight );

	glViewport( 0, 0, iwidth, iheight );

	// Load shader program
	ShaderProgram prog({
		{ GL_VERTEX_SHADER, "assets/default.vert" },
		{ GL_FRAGMENT_SHADER, "assets/default.frag" }
		});

	// Load textures
	GLuint markus_texture = load_texture_2d("assets/markus.png");
	GLuint no_texture = load_texture_2d("assets/blank.png");
	GLuint stickerbomb_texture = load_texture_2d("assets/stickerbomb.png");
	GLuint windows_texture = load_texture_2d("assets/windows-logo.png");
	GLuint lecture01_texture = load_texture_2d("assets/lecture-01.png");
	GLuint lecture02_texture = load_texture_2d("assets/lecture-02.png");
	GLuint lecture03_texture = load_texture_2d("assets/lecture-03.png");
	GLuint lecture04_texture = load_texture_2d("assets/lecture-04.png");
	GLuint hands_texture = load_texture_2d("assets/sam-hands.png");
	GLuint sam_texture = load_texture_2d("assets/sam-meowmere.png");

	state.prog = &prog;

	// Animation state
	auto last = Clock::now();
	float animationOffset = 0.f;
	int animationDirection = -1;
	float animationMagnitude = -20.f;
	int slideIndex = 0;
	float slideChangeTime = 0;

	// Lighting State

	state.lighting.light01.color = Vec3f{ 1.f, 1.f, 1.f };
	state.lighting.light01.pos = Vec3f{ .0f, 60.f, 20.f };
	state.lighting.light01.strength = 100.f;

	state.lighting.light02.color = Vec3f{ 1, 0, 0, };
	state.lighting.light02.pos = Vec3f{ 25.f, 1.f, 0.f };
	state.lighting.light02.strength = 1.f;

	state.lighting.light03.color = Vec3f{ 0, 1, 0, };
	state.lighting.light03.pos = Vec3f{ -45.f, 100.f, 135.f };
	state.lighting.light03.strength = 10.f;

	state.lighting.ambient.color = Vec3f{ 0.05f, 0.05f, 0.05f };

	// Material State

	state.materials.general = Vec3f{ 10.f, 0.01f, 0.f };
	state.materials.shiny = Vec3f{ 10.f, 50.f, 0.f };
	state.materials.emissive = Vec3f{ 0.f, 0.f, 1.f };


	// Setup static lit meshes
	std::vector<SimpleMeshData> staticLitMeshes = setup_static_lit_meshes(&state);

	// Other initialization & loading
	OGL_CHECKPOINT_ALWAYS();
	
	// Bind textures to specific locations
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, no_texture);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, markus_texture);

	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, stickerbomb_texture);

	glActiveTexture(GL_TEXTURE3);
	glBindTexture(GL_TEXTURE_2D, windows_texture);

	glActiveTexture(GL_TEXTURE4);
	glBindTexture(GL_TEXTURE_2D, lecture01_texture);

	glActiveTexture(GL_TEXTURE5);
	glBindTexture(GL_TEXTURE_2D, hands_texture);

	glActiveTexture(GL_TEXTURE6);
	glBindTexture(GL_TEXTURE_2D, sam_texture);

	OGL_CHECKPOINT_ALWAYS();


	// Initialise ImGUI
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGui::StyleColorsDark();
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init("#version 440");


	// Main loop
	while( !glfwWindowShouldClose( window ) )
	{
		// Let GLFW process events
		glfwPollEvents();
		
		// Check if window was resized.
		float fbwidth, fbheight;
		{
			int nwidth, nheight;
			glfwGetFramebufferSize( window, &nwidth, &nheight );

			fbwidth = float(nwidth);
			fbheight = float(nheight);

			if( 0 == nwidth || 0 == nheight )
			{
				// Window minimized? Pause until it is unminimized.
				// This is a bit of a hack.
				do
				{
					glfwWaitEvents();
					glfwGetFramebufferSize( window, &nwidth, &nheight );
				} while( 0 == nwidth || 0 == nheight );
			}

			glViewport( 0, 0, (GLsizei)fbwidth, (GLsizei)fbheight); // Resize view to new size
		}

		// Update state

		auto const now = Clock::now();
		float dt = std::chrono::duration_cast<Secondsf>(now - last).count();
		last = now;

		// Apply animation state 
		if (!state.animControl.animationPaused)
		{
			animationOffset += animationDirection * state.animControl.speed * dt;
		}

		if (animationOffset < animationMagnitude || animationOffset > 0)
		{
			animationDirection *= -1;
		}


		slideChangeTime += dt;

		if (slideChangeTime >= state.animControl.slideChangeTime)
		{
			if (slideIndex == 0)
			{
				glActiveTexture(GL_TEXTURE4);
				glBindTexture(GL_TEXTURE_2D, lecture01_texture);
				slideChangeTime = 0;
				slideIndex++;
			}
			else if (slideIndex == 1)
			{
				glActiveTexture(GL_TEXTURE4);
				glBindTexture(GL_TEXTURE_2D, lecture02_texture);
				slideChangeTime = 0;
				slideIndex++;
			}
			else if (slideIndex == 2)
			{
				glActiveTexture(GL_TEXTURE4);
				glBindTexture(GL_TEXTURE_2D, lecture03_texture);
				slideChangeTime = 0;
				slideIndex++;
			}
			else if (slideIndex == 3)
			{
				glActiveTexture(GL_TEXTURE4);
				glBindTexture(GL_TEXTURE_2D, lecture04_texture);
				slideChangeTime = 0;
				slideIndex = 0;
			}
		}

		// Setup Lights
		Light animatedLight02 = Light{ state.lighting.light02 };
		animatedLight02.pos.z += animationOffset;

		std::vector<Light> lights;
		lights.emplace_back(state.lighting.light01);
		lights.emplace_back(animatedLight02);
		lights.emplace_back(state.lighting.light03);

		// Update camera state/position

		float fov = 70.f;
		float aspectRatio = fbwidth / float(fbheight);

		state.camControl.pos += state.camControl.deltaPos * dt;
		state.camControl.deltaPos = { 0, 0, 0 };

		Mat44f pitch = make_rotation_x(state.camControl.pitch);
		Mat44f yaw = make_rotation_y(state.camControl.yaw);
		Mat44f translation = make_translation({ state.camControl.pos.x, state.camControl.pos.y, state.camControl.pos.z });
		
		// Projection
		Mat44f world2camera = pitch * yaw * translation;
		Mat44f model2world = kIdentity44f;

		Mat44f projection = make_perspective_projection(
			d2r(fov), // Convert fov to radians
			aspectRatio,
			0.1f, 100.0f
		);
		Mat44f projCameraWorld = projection * world2camera * model2world;

		state.camControl.world2camera = invert(world2camera);
		state.camControl.billboardTransform = make_rotation_y(-state.camControl.yaw);

		if (state.camControl.pitchBillboards)
		{
			state.camControl.billboardTransform = state.camControl.billboardTransform * make_rotation_x(-state.camControl.pitch);
		}

		// Calculate normals, ambient lighting and view vector
		Mat33f normalMatrix = mat44_to_mat33(transpose(invert(model2world)));
		Vec4f viewVector = world2camera * Vec4f{ 1.f, 1.f, 1.f, 1.f };


		// Update dynamic meshes, combine lit mesh lists and create VAOs
		std::vector<SimpleMeshData> debugMeshes = setup_static_debug_meshes(lights);
		GLuint debugVao = create_vao(debugMeshes);
		std::size_t debugVertexCount = get_mesh_vertex_count(debugMeshes);

		std::vector<SimpleMeshData> dynamicLitMeshes = setup_dynamic_lit_meshes(Vec3f{ 0,0, animationOffset }, &state);
		std::vector<SimpleMeshData> combinedLitMeshes = staticLitMeshes;
		for (SimpleMeshData smd : dynamicLitMeshes)
		{
			combinedLitMeshes.emplace_back(smd);
		}

		GLuint defaultLightVao = create_vao(combinedLitMeshes);
		std::size_t defaultLightVertexCount = get_mesh_vertex_count(combinedLitMeshes);

		// Draw scene
		OGL_CHECKPOINT_DEBUG();

		// Reset frame
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Reset Debug UI
		ImGui_ImplOpenGL3_NewFrame();
		ImGui_ImplGlfw_NewFrame();
		ImGui::NewFrame();

		// We want to draw with our program
		glUseProgram(prog.programId());
		
		// Only show debug objects if in debug state
		if (state.debugUi.showDebug)
		{
			draw_unlit_meshes(debugVao, debugVertexCount, projCameraWorld);
		}

		draw_default_light_meshes(defaultLightVao, defaultLightVertexCount, projCameraWorld,
			normalMatrix, state.lighting.ambient.color, lights, Vec3f{ viewVector.x, viewVector.y, viewVector.z}, &state);

		// Take screenshot?
		if (state.camControl.takeScreenshot)
		{
			state.camControl.takeScreenshot = false;

			// Get time and format it into filename
			time_t currentTime;
			tm* localTime;
			time(&currentTime);
			localTime = localtime(&currentTime);
			char filename[100];

			strftime(filename, 50, "screenshot %Y-%m-%d %H-%M-%S.png", localTime);

			printf("Taking screenshot '%s'\n", filename);

			// Get data from GL framebuffer
			static GLubyte* data = new GLubyte[3 * (GLsizei)fbwidth * (GLsizei)fbheight];
			glReadPixels(0, 0, (GLsizei)fbwidth, (GLsizei)fbheight, GL_SRGB, GL_UNSIGNED_BYTE, data);
			stbi_flip_vertically_on_write(1); // We need this, otherwise the screenshot is upside-down

			stbi_write_png(filename, (int)fbwidth, (int)fbheight, 3, data, (int)fbwidth * 3); // Write the file
		}

		//Draw Debug UI
		if (state.camControl.showDebugUi)
		{
			ImGui::Begin("General Debug");
			ImGui::Text("%s", (std::to_string(1 / dt) + " fps").c_str());
			ImGui::Text("%s", (std::to_string(dt) + " spf").c_str());

			ImGui::Checkbox("Draw Debug Objects?", &state.debugUi.showDebug);
			ImGui::Checkbox("Draw Wireframe?", &state.debugUi.drawWireFrame);
			ImGui::Checkbox("Draw Hands?", &state.debugUi.drawHands);
			ImGui::Checkbox("Draw OBJ?", &state.debugUi.drawObj);
			ImGui::Checkbox("Pitch Billboards?", &state.camControl.pitchBillboards);

			ImGui::Text("Camera Speed");
			ImGui::SliderFloat("Base", &state.camControl.speed, 1.f, 200.f);
			ImGui::SliderFloat("Fast Modifier", &state.camControl.fastModifier, 1.f, 10.f);
			ImGui::SliderFloat("Slow Modifier", &state.camControl.slowModifier, 0.f, 1.f);

			ImGui::End();


			ImGui::Begin("Lighting Controls");

			if (ImGui::TreeNode("Light 1"))
			{
				float col[3] = { state.lighting.light01.color.x, state.lighting.light01.color.y, state.lighting.light01.color.z };
				ImGui::ColorEdit3("Colour", col);
				state.lighting.light01.color.x = col[0];
				state.lighting.light01.color.y = col[1];
				state.lighting.light01.color.z = col[2];
				ImGui::Spacing();
				ImGui::SliderFloat("Strength", &state.lighting.light01.strength, 0.f, 200.f);

				ImGui::Text("Position");
				ImGui::SliderFloat("X", &state.lighting.light01.pos.x, -100.f, 200.f);
				ImGui::SliderFloat("Y", &state.lighting.light01.pos.y, -100.f, 200.f);
				ImGui::SliderFloat("Z", &state.lighting.light01.pos.z, -100.f, 200.f);
				ImGui::TreePop();
			}			

			if (ImGui::TreeNode("Light 2"))
			{
				float col[3] = { state.lighting.light02.color.x, state.lighting.light02.color.y, state.lighting.light02.color.z };
				ImGui::ColorEdit3("Colour", col);
				state.lighting.light02.color.x = col[0];
				state.lighting.light02.color.y = col[1];
				state.lighting.light02.color.z = col[2];
				ImGui::Spacing();
				ImGui::SliderFloat("Strength", &state.lighting.light02.strength, 0.f, 200.f);

				ImGui::Text("Position");
				ImGui::SliderFloat("X", &state.lighting.light02.pos.x, -100.f, 200.f);
				ImGui::SliderFloat("Y", &state.lighting.light02.pos.y, -100.f, 200.f);
				ImGui::SliderFloat("Z", &state.lighting.light02.pos.z, -100.f, 200.f);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Light 3"))
			{
				float col[3] = { state.lighting.light03.color.x, state.lighting.light03.color.y, state.lighting.light03.color.z };
				ImGui::ColorEdit3("Colour", col);
				state.lighting.light03.color.x = col[0];
				state.lighting.light03.color.y = col[1];
				state.lighting.light03.color.z = col[2];
				ImGui::Spacing();
				ImGui::SliderFloat("Strength", &state.lighting.light03.strength, 0.f, 200.f);

				ImGui::Text("Position");
				ImGui::SliderFloat("X", &state.lighting.light03.pos.x, -100.f, 200.f);
				ImGui::SliderFloat("Y", &state.lighting.light03.pos.y, -100.f, 200.f);
				ImGui::SliderFloat("Z", &state.lighting.light03.pos.z, -100.f, 200.f);
				ImGui::Text("Strength");
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Ambient"))
			{
				float col[3] = { state.lighting.ambient.color.x, state.lighting.ambient.color.y, state.lighting.ambient.color.z };
				ImGui::ColorEdit3("Colour", col);
				state.lighting.ambient.color.x = col[0];
				state.lighting.ambient.color.y = col[1];
				state.lighting.ambient.color.z = col[2];

				ImGui::TreePop();
			}

			ImGui::End();


			ImGui::Begin("Animation Controls");

			if (ImGui::TreeNode("Markus Robot"))
			{
				ImGui::SliderFloat("Speed", &state.animControl.speed, 0.f, 10.f);
				ImGui::Checkbox("Paused", &state.animControl.animationPaused);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Lecture Slides"))
			{
				ImGui::SliderFloat("Slide Duration (s)", &state.animControl.slideChangeTime, 0.f, 60.f);
				ImGui::TreePop();
			}

			ImGui::End();


			ImGui::Begin("Material Settings");

			if (ImGui::TreeNode("Generic"))
			{
				ImGui::SliderFloat("Diffuse",  &state.materials.general.x, 0.f, 100.f);
				ImGui::SliderFloat("Specular", &state.materials.general.y, 0.f, 200.f);
				ImGui::SliderFloat("Emissive", &state.materials.general.z, 0.f, 2.f);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Wood / Shiny Metal"))
			{
				ImGui::SliderFloat("Diffuse",  &state.materials.shiny.x, 0.f, 100.f);
				ImGui::SliderFloat("Specular", &state.materials.shiny.y, 0.f, 200.f);
				ImGui::SliderFloat("Emissive", &state.materials.shiny.z, 0.f, 2.f);
				ImGui::TreePop();
			}

			if (ImGui::TreeNode("Display / Glow"))
			{
				ImGui::SliderFloat("Diffuse",  &state.materials.emissive.x, 0.f, 100.f);
				ImGui::SliderFloat("Specular", &state.materials.emissive.y, 0.f, 200.f);
				ImGui::SliderFloat("Emissive", &state.materials.emissive.z, 0.f, 2.f);
				ImGui::TreePop();
			}			

			ImGui::End();
		}

		ImGui::Render();
		ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

		// Reset state
		glBindVertexArray(0);
		glUseProgram(0);

		OGL_CHECKPOINT_DEBUG();

		// Display results
		glfwSwapBuffers( window );
	}

	// Cleanup.

	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplGlfw_Shutdown();
	ImGui::DestroyContext();

	glDeleteTextures(1, &no_texture);
	glDeleteTextures(1, &markus_texture);
	glDeleteTextures(1, &stickerbomb_texture);
	glDeleteTextures(1, &windows_texture);
	glDeleteTextures(1, &lecture01_texture);
	glDeleteTextures(1, &lecture02_texture);
	glDeleteTextures(1, &lecture03_texture);
	glDeleteTextures(1, &lecture04_texture);
	glDeleteTextures(1, &hands_texture);
	
	return 0;
}
catch( std::exception const& eErr )
{
	std::fprintf( stderr, "Top-level Exception (%s):\n", typeid(eErr).name() );
	std::fprintf( stderr, "%s\n", eErr.what() );
	std::fprintf( stderr, "Bye.\n" );
	return 1;
}


namespace
{
	void glfw_callback_error_( int aErrNum, char const* aErrDesc )
	{
		std::fprintf( stderr, "GLFW error: %s (%d)\n", aErrDesc, aErrNum );
	}

	// Handle keyboard events
	void glfw_callback_key_(GLFWwindow* aWindow, int aKey, int, int aAction, int aModifiers)
	{
		if (GLFW_KEY_ESCAPE == aKey && GLFW_PRESS == aAction)
		{
			glfwSetWindowShouldClose(aWindow, GLFW_TRUE);
			return;
		}

		if (auto* state = static_cast<State_*>(glfwGetWindowUserPointer(aWindow)))
		{
			// R-key reloads shaders.
			if (GLFW_KEY_R == aKey && GLFW_PRESS == aAction)
			{
				if (state->prog)
				{
					try
					{
						state->prog->reload();
						std::fprintf(stderr, "Shaders reloaded and recompiled.\n");
					}
					catch (std::exception const& eErr)
					{
						std::fprintf(stderr, "Error when reloading shader:\n");
						std::fprintf(stderr, "%s\n", eErr.what());
						std::fprintf(stderr, "Keeping old shader.\n");
					}
				}
			}

			// Space toggles camera
			if (GLFW_KEY_SPACE == aKey && GLFW_PRESS == aAction)
			{
				state->camControl.cameraActive = !state->camControl.cameraActive;

				if (state->camControl.cameraActive)
					glfwSetInputMode(aWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
				else
					glfwSetInputMode(aWindow, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
			}
			// Toggle showing debug UI
			else if (GLFW_KEY_X == aKey && aAction == GLFW_PRESS) 
			{
				state->camControl.showDebugUi = !state->camControl.showDebugUi;
			}

			float speed = state->camControl.speed;

			// Camera controls if camera is active
			if (state->camControl.cameraActive)
			{
				// Determine speed modifiers
				if (GLFW_MOD_SHIFT == aModifiers)
				{
					speed *= state->camControl.fastModifier;
				}
				else if (GLFW_MOD_CONTROL == aModifiers)
				{
					speed *= state->camControl.slowModifier;
				}

				// Determine delta values for use in moving camera according to rotation
				float sineYaw = sin(state->camControl.yaw);
				float cosineYaw = cos(state->camControl.yaw);
				float sinePitch = sin(state->camControl.pitch);

				if (GLFW_KEY_W == aKey) // Movement - forward
				{
					state->camControl.deltaPos.x -= speed * sineYaw;
					state->camControl.deltaPos.z += speed * cosineYaw;
					state->camControl.deltaPos.y += speed * sinePitch;
				}
				else if (GLFW_KEY_S == aKey) // Movement - backward
				{
					state->camControl.deltaPos.x += speed * sineYaw;
					state->camControl.deltaPos.z -= speed * cosineYaw;
					state->camControl.deltaPos.y -= speed * sinePitch;
				}
				else if (GLFW_KEY_D == aKey) // Movement - right
				{
					state->camControl.deltaPos.x -= speed * cosineYaw;
					state->camControl.deltaPos.z -= speed * sineYaw;
				}
				else if (GLFW_KEY_A == aKey) // Movement - left
				{
					state->camControl.deltaPos.x += speed * cosineYaw;
					state->camControl.deltaPos.z += speed * sineYaw;
				}
				else if (GLFW_KEY_Q == aKey) // Movement - down
				{
					state->camControl.deltaPos.y += speed;
				}
				else if (GLFW_KEY_E == aKey) // Movement - up
				{
					state->camControl.deltaPos.y -= speed;
				}

				else if (GLFW_KEY_Z == aKey) // Reset camera position
				{
					state->camControl.deltaPos = { 0, 0, 0 };
					state->camControl.pos = state->camControl.defaultPos;
					state->camControl.pitch = state->camControl.defaultPitch;
					state->camControl.yaw = state->camControl.defaultYaw;
				}
				else if (GLFW_KEY_C == aKey && aAction == GLFW_PRESS) // Output camera position to console
				{
					printf("=== CAMERA POSITION ===\n");
					printf("Pos: (%f,%f,%f)\n", state->camControl.pos.x, state->camControl.pos.y, state->camControl.pos.z);
					printf("Pitch: %f Yaw: %f\n", state->camControl.pitch, state->camControl.yaw);
				}
				else if (GLFW_KEY_V == aKey && aAction == GLFW_PRESS) // Take screenshot
				{
					state->camControl.takeScreenshot = true;
				}

				else if (GLFW_KEY_COMMA == aKey && aAction == GLFW_PRESS) // Animation - Decrease speed
				{
					state->animControl.speed -= state->animControl.speedModifier;
				}
				else if (GLFW_KEY_PERIOD == aKey && aAction == GLFW_PRESS) // Animation - Increase speed
				{
					state->animControl.speed += state->animControl.speedModifier;
				}
				else if (GLFW_KEY_SLASH == aKey && aAction == GLFW_PRESS) // Animation - Pause
				{
					state->animControl.animationPaused = !state->animControl.animationPaused;
				}
			}
		}
	}

	const float maxPitch = d2r(90);

	// Handle mouse events
	void glfw_callback_motion_(GLFWwindow* aWindow, double aX, double aY)
	{
		float x = float(aX);
		float y = float(aY);

		if (auto* state = static_cast<State_*>(glfwGetWindowUserPointer(aWindow)))
		{
			// Update rotation state
			if (state->camControl.cameraActive) 
			{
				state->camControl.yaw += (x - state->camControl.currentX) * 0.01f;
				state->camControl.pitch -= (state->camControl.currentY - y) * 0.01f;
			}

			// Clamp looking up & down to 180 degrees
			if (state->camControl.pitch > maxPitch)
			{
				state->camControl.pitch = maxPitch;
			}
			else if (state->camControl.pitch < -maxPitch)
			{
				state->camControl.pitch = -maxPitch;
			}

			state->camControl.currentX = x;
			state->camControl.currentY = y;
		}
	}
}

namespace
{
	GLFWCleanupHelper::~GLFWCleanupHelper()
	{
		glfwTerminate();
	}

	GLFWWindowDeleter::~GLFWWindowDeleter()
	{
		if( window )
			glfwDestroyWindow( window );
	}
}

