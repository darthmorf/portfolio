#include "simple_mesh.hpp"

SimpleMeshData concatenate(SimpleMeshData aM, SimpleMeshData const& aN)
{
	aM.positions.insert(aM.positions.end(), aN.positions.begin(), aN.positions.end());
	aM.colors.insert(aM.colors.end(), aN.colors.begin(), aN.colors.end());
	aM.normals.insert(aM.normals.end(), aN.normals.begin(), aN.normals.end());
	aM.diffuseSpecularEmissive.insert(aM.diffuseSpecularEmissive.end(), aN.diffuseSpecularEmissive.begin(), aN.diffuseSpecularEmissive.end());
	aM.texcoords.insert(aM.texcoords.end(), aN.texcoords.begin(), aN.texcoords.end());
	aM.textureIndex.insert(aM.textureIndex.end(), aN.textureIndex.begin(), aN.textureIndex.end());
	return aM;
}

size_t get_mesh_vertex_count(std::vector<SimpleMeshData> aMeshes)
{
	size_t totalSize = 0;

	for (SimpleMeshData mesh : aMeshes)
	{
		totalSize += mesh.positions.size();
	}

	return totalSize;
}

size_t get_mesh_color_count(std::vector<SimpleMeshData> aMeshes)
{
	size_t totalSize = 0;

	for (SimpleMeshData mesh : aMeshes)
	{
		totalSize += mesh.colors.size();
	}

	return totalSize;
}

size_t get_mesh_normal_count(std::vector<SimpleMeshData> aMeshes)
{
	size_t totalSize = 0;

	for (SimpleMeshData mesh : aMeshes)
	{
		totalSize += mesh.normals.size();
	}

	return totalSize;
}

size_t get_mesh_diffuseSpecularEmissive_count(std::vector<SimpleMeshData> aMeshes)
{
	size_t totalSize = 0;

	for (SimpleMeshData mesh : aMeshes)
	{
		totalSize += mesh.diffuseSpecularEmissive.size();
	}

	return totalSize;
}

size_t get_mesh_texcoords_count(std::vector<SimpleMeshData> aMeshes)
{
	size_t totalSize = 0;

	for (SimpleMeshData mesh : aMeshes)
	{
		totalSize += mesh.texcoords.size();
	}

	return totalSize;
}

size_t get_mesh_texindex_count(std::vector<SimpleMeshData> aMeshes)
{
	size_t totalSize = 0;

	for (SimpleMeshData mesh : aMeshes)
	{
		totalSize += mesh.textureIndex.size();
	}

	return totalSize;
}


GLuint create_vao(std::vector<SimpleMeshData> aMeshes)
{
	// VBO

	GLuint positionVBO = 0;
	GLuint colorVBO = 0;
	GLuint normalVBO = 0;
	GLuint diffuseSpecularEmissiveVBO = 0;
	GLuint texcoordsVBO = 0;
	GLuint texIndexVBO = 0;

	size_t totalPosSize = get_mesh_vertex_count(aMeshes) * sizeof(Vec3f);
	size_t totalColorSize = get_mesh_color_count(aMeshes) * sizeof(Vec4f);
	size_t totalNormalSize = get_mesh_normal_count(aMeshes) * sizeof(Vec3f);
	size_t totalDiffuseSpecularEmissiveSize = get_mesh_diffuseSpecularEmissive_count(aMeshes) * sizeof(Vec3f);
	size_t totalTexcoordsSize = get_mesh_texcoords_count(aMeshes) * sizeof(Vec2f);
	size_t totalTexIndexSize = get_mesh_texindex_count(aMeshes) * sizeof(Vec3f);

	glGenBuffers(1, &positionVBO);
	glBindBuffer(GL_ARRAY_BUFFER, positionVBO);
	glBufferData(GL_ARRAY_BUFFER, totalPosSize, 0, GL_STATIC_DRAW);

	glGenBuffers(1, &colorVBO);
	glBindBuffer(GL_ARRAY_BUFFER, colorVBO);
	glBufferData(GL_ARRAY_BUFFER, totalColorSize, 0, GL_STATIC_DRAW);

	glGenBuffers(1, &normalVBO);
	glBindBuffer(GL_ARRAY_BUFFER, normalVBO);
	glBufferData(GL_ARRAY_BUFFER, totalNormalSize, 0, GL_STATIC_DRAW);

	glGenBuffers(1, &diffuseSpecularEmissiveVBO);
	glBindBuffer(GL_ARRAY_BUFFER, diffuseSpecularEmissiveVBO);
	glBufferData(GL_ARRAY_BUFFER, totalDiffuseSpecularEmissiveSize, 0, GL_STATIC_DRAW);

	glGenBuffers(1, &texcoordsVBO);
	glBindBuffer(GL_ARRAY_BUFFER, texcoordsVBO);
	glBufferData(GL_ARRAY_BUFFER, totalTexcoordsSize, 0, GL_STATIC_DRAW);

	glGenBuffers(1, &texIndexVBO);
	glBindBuffer(GL_ARRAY_BUFFER, texIndexVBO);
	glBufferData(GL_ARRAY_BUFFER, totalTexIndexSize, 0, GL_STATIC_DRAW);

	size_t currentPosIndex = 0;
	size_t currentColorIndex = 0;
	size_t currentNormalIndex = 0;
	size_t currentDiffuseSpecularEmissiveIndex = 0;
	size_t currentTexcoordsIndex = 0;
	size_t currentTexIndexIndex = 0;

	for (SimpleMeshData mesh : aMeshes)
	{
		size_t currentPosSize = mesh.positions.size() * sizeof(Vec3f);
		size_t currentColorSize = mesh.colors.size() * sizeof(Vec4f);
		size_t currentNormalSize = mesh.normals.size() * sizeof(Vec3f);
		size_t currentDiffuseSpecularEmissiveSize = mesh.diffuseSpecularEmissive.size() * sizeof(Vec3f);
		size_t currentTexcoordsSize = mesh.texcoords.size() * sizeof(Vec2f);
		size_t currentTexIndexSize = mesh.textureIndex.size() * sizeof(Vec3f);

		glBindBuffer(GL_ARRAY_BUFFER, positionVBO);
		glBufferSubData(GL_ARRAY_BUFFER, currentPosIndex, currentPosSize, mesh.positions.data());
		glBindBuffer(GL_ARRAY_BUFFER, colorVBO);
		glBufferSubData(GL_ARRAY_BUFFER, currentColorIndex, currentColorSize, mesh.colors.data());
		glBindBuffer(GL_ARRAY_BUFFER, normalVBO);
		glBufferSubData(GL_ARRAY_BUFFER, currentNormalIndex, currentNormalSize, mesh.normals.data());
		glBindBuffer(GL_ARRAY_BUFFER, diffuseSpecularEmissiveVBO);
		glBufferSubData(GL_ARRAY_BUFFER, currentDiffuseSpecularEmissiveIndex, currentDiffuseSpecularEmissiveSize, mesh.diffuseSpecularEmissive.data());
		glBindBuffer(GL_ARRAY_BUFFER, texcoordsVBO);
		glBufferSubData(GL_ARRAY_BUFFER, currentTexcoordsIndex, currentTexcoordsSize, mesh.texcoords.data());
		glBindBuffer(GL_ARRAY_BUFFER, texIndexVBO);
		glBufferSubData(GL_ARRAY_BUFFER, currentTexIndexIndex, currentTexIndexSize, mesh.textureIndex.data());

		currentPosIndex += currentPosSize;
		currentColorIndex += currentColorSize;
		currentNormalIndex += currentNormalSize;
		currentDiffuseSpecularEmissiveIndex += currentDiffuseSpecularEmissiveSize;
		currentTexcoordsIndex += currentTexcoordsSize;
		currentTexIndexIndex += currentTexIndexSize;
	}

	// VAO

	GLuint vao = 0;

	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	glBindBuffer(GL_ARRAY_BUFFER, positionVBO);
	glVertexAttribPointer(
		0, // Location 0 in vertex shader
		3, GL_FLOAT, GL_FALSE, // 3 floats, not normalised to [0..1] (GL_FALSE)
		0, // Stride
		0  // Data starts at offset 0 in the VBO
	);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, colorVBO);
	glVertexAttribPointer(
		1, // Location 1 in vertex shader
		4, GL_FLOAT, GL_FALSE, // 4 floats, not normalised to [0..1] (GL_FALSE)
		0, // Stride
		0  // Data starts at offset 0 in the VBO
	);
	glEnableVertexAttribArray(1);

	glBindBuffer(GL_ARRAY_BUFFER, normalVBO);
	glVertexAttribPointer(
		2,
		3, GL_FLOAT, GL_FALSE,
		0,
		0 
	);
	glEnableVertexAttribArray(2);

	glBindBuffer(GL_ARRAY_BUFFER, diffuseSpecularEmissiveVBO);
	glVertexAttribPointer(
		3,
		3, GL_FLOAT, GL_FALSE,
		0,
		0 
	);
	glEnableVertexAttribArray(3);

	glBindBuffer(GL_ARRAY_BUFFER, texcoordsVBO);
	glVertexAttribPointer(
		4,
		2, GL_FLOAT, GL_FALSE,
		0,
		nullptr
	);
	glEnableVertexAttribArray(4);

	glBindBuffer(GL_ARRAY_BUFFER, texIndexVBO);
	glVertexAttribPointer(
		5,
		3, GL_FLOAT, GL_FALSE,
		0,
		0
	);
	glEnableVertexAttribArray(5);

	// Reset State
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	// Clean up buffers - note: these are not deleted fully, as the VAO holds a reference to them.
	glDeleteBuffers(1, &positionVBO);
	glDeleteBuffers(1, &colorVBO);
	glDeleteBuffers(1, &normalVBO);
	glDeleteBuffers(1, &diffuseSpecularEmissiveVBO);
	glDeleteBuffers(1, &texcoordsVBO);
	glDeleteBuffers(1, &texIndexVBO);

	return vao;
}


GLuint create_vao(SimpleMeshData const& aMeshData)
{
	return create_vao(std::vector<SimpleMeshData>{ aMeshData });
}

GLuint load_texture_2d(char const* aPath)
{
	assert(aPath); 
	
	// Load image first
	// This may fail (e.g., image does not exist), so there's no point in allocating OpenGL resources ahead of time. 
	stbi_set_flip_vertically_on_load( true );

	int w, h, channels;
	stbi_uc* ptr = stbi_load( aPath, &w, &h, &channels, 4 );
	if( !ptr )
		throw Error("Unable to load image '%s'\n", aPath);

	// Generate texture object and initialize texture with image
	GLuint tex = 0;
	glGenTextures( 1, &tex );
	glBindTexture( GL_TEXTURE_2D, tex );

	glTexImage2D( GL_TEXTURE_2D, 0, GL_SRGB8_ALPHA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, ptr );

	stbi_image_free( ptr );
	
	// Generate mipmap hierarchy 
	glGenerateMipmap( GL_TEXTURE_2D );
	
	// Configure texture
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );

	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );

	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY, 6.f );

	return tex;
}

SimpleMeshData load_wavefront_obj(char const* aPath, Vec4f aColor, float aDiffuse, float aSpecular, float aEmissive, Mat44f aPreTransform)
{
	// Unused paramters
	(void)aColor;
	(void)aDiffuse;
	(void)aSpecular;
	(void)aEmissive;


	// Ask rapidobj file to load the requested file
	auto result = rapidobj::ParseFile(aPath);

	if (result.error)
	{
		throw Error("Unable to load OBJ file '%s' : %s", aPath, result.error.code.message().c_str());
	}

	// OBJ files can define faces that are not triangles. However, OpenGL will only render triangles (and lines and points),
	// so we must triangulate any faces that are not already triangles. Fortunately, rapidobj can do this for us.
	rapidobj::Triangulate(result);

	// Convert the OBJ data into a SimpleMeshData structure. 
	// For now, we simply turn the object into a triangle soup, ignoring the indexing information that the OBJ file contains

	std::vector<Vec3f> positions = {};
	std::vector<Vec3f> normals = {};
	std::vector<Vec2f> texcoords = {};
	std::vector<Vec4f> colors = {};
	std::vector<Vec3f> diffuseSpecularEmissive = {};
	std::vector<Vec3f> textureIndex = {};

	Mat33f const N = mat44_to_mat33(transpose(invert(aPreTransform)));

	for (auto const& shape : result.shapes)
	{
		for (std::size_t i = 0; i < shape.mesh.indices.size(); ++i)
		{
			auto const& idx = shape.mesh.indices[i];

			Vec4f pos = Vec4f{
				result.attributes.positions[idx.position_index * 3 + 0],
				result.attributes.positions[idx.position_index * 3 + 1],
				result.attributes.positions[idx.position_index * 3 + 2],
				1.f
			};

			Vec4f t = aPreTransform * pos;
			t /= t.w;

			positions.emplace_back(Vec3f{ t.x, t.y, t.z });

			normals.emplace_back(normalize(N * Vec3f{
				result.attributes.normals[idx.position_index * 3 + 0],
				result.attributes.normals[idx.position_index * 3 + 1],
				result.attributes.normals[idx.position_index * 3 + 2],
			}));			

			auto const& mat = result.materials[shape.mesh.material_ids[i / 3]];

			if ((size_t)idx.position_index * 3 > result.attributes.texcoords.size())
			{
				texcoords.emplace_back(Vec2f{
					0,
					0,
				});
			}
			else
			{
				texcoords.emplace_back(Vec2f{
					result.attributes.texcoords[idx.position_index * 3 + 0],
					result.attributes.texcoords[idx.position_index * 3 + 1],
				});
			}

			colors.emplace_back(Vec4f{
					mat.ambient[0],
					mat.ambient[1],
					mat.ambient[2],
					1.f
				});

			diffuseSpecularEmissive.emplace_back(Vec3f{ mat.diffuse[0] * mat.shininess, mat.specular[0] * mat.shininess / 2, mat.emission[0]});
			textureIndex.emplace_back(Vec3f{ 0, 0, 0 });
		}
	}

	return SimpleMeshData{ std::move(positions), std::move(colors), std::move(normals), std::move(diffuseSpecularEmissive), std::move(texcoords), std::move(textureIndex) };;
}