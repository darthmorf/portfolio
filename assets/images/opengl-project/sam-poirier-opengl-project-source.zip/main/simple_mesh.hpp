#ifndef SIMPLE_MESH_HPP_C6B749D6_C83B_434C_9E58_F05FC27FEFC9
#define SIMPLE_MESH_HPP_C6B749D6_C83B_434C_9E58_F05FC27FEFC9

#include <glad.h>
#include <stb_image.h>
#include <rapidobj/rapidobj.hpp>

#include <vector>

#include "../vmlib/vec2.hpp"
#include "../vmlib/vec3.hpp"
#include "../vmlib/mat44.hpp"
#include "../vmlib/mat33.hpp"
#include "../support/error.hpp"


struct SimpleMeshData
{
	std::vector<Vec3f> positions;
	std::vector<Vec4f> colors;
	std::vector<Vec3f> normals;
	std::vector<Vec3f> materials;
	std::vector<Vec2f> texcoords;
	std::vector<Vec3f> textureIndex;
};


void update_vao(std::vector<SimpleMeshData>* aMeshes, GLuint* vao, GLuint* positionVBO, GLuint* colorVBO, GLuint* normalVBO, GLuint* materialVBO, GLuint* texcoordsVBO, GLuint* texIndexVBO);
void update_vao(SimpleMeshData *const&, GLuint* vao, GLuint* positionVBO, GLuint* colorVBO, GLuint* normalVBO, GLuint* materialVBO, GLuint* texcoordsVBO, GLuint* texIndexVBO);
size_t get_mesh_vertex_count(std::vector<SimpleMeshData>* aMeshes);
size_t get_mesh_color_count(std::vector<SimpleMeshData>* aMeshes);
size_t get_mesh_normal_count(std::vector<SimpleMeshData>* aMeshes);
size_t get_mesh_material_count(std::vector<SimpleMeshData>* aMeshes);
void concatenate( SimpleMeshData* aM, SimpleMeshData* const& aN);
GLuint load_texture_2d(char const* aPath);
void update_material(SimpleMeshData* aMesh, Vec3f* aMaterial);
SimpleMeshData load_wavefront_obj(
	char const* aPath,
	Vec4f aColor = { 1.f, 1.f, 1.f, 1.f },
	Vec3f* aMaterial = 0,
	Mat44f aPreTransform = kIdentity44f
);

#endif // SIMPLE_MESH_HPP_C6B749D6_C83B_434C_9E58_F05FC27FEFC9
